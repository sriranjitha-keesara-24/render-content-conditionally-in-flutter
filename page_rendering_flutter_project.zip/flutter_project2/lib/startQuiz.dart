import 'package:flutter/material.dart';
import 'package:flutter_project2/componentspage.dart';
import 'package:flutter_project2/functionpage.dart';
import 'package:flutter_project2/page1.dart';

class QuizQuestions extends StatefulWidget{
  const QuizQuestions({super.key});
  @override
  State<QuizQuestions> createState(){
    return _QuizQuestionsStart();
  }
}
class _QuizQuestionsStart extends State<QuizQuestions>{
    @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // active = null;
  }
  Widget? active;
  void functions(){
    setState(() {
      active = const FunctionsPage();
    });
  }
 

  void components(){
    setState(() {
     active = Componentspage();
    });
  }

  void blocks(){

  }
  void widgets(){

  }
  @override
    Widget build(BuildContext context){
    return Container(
      
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
      gradient: LinearGradient(colors: [Color.fromARGB(217, 26, 113, 235),Color.fromARGB(184, 155, 9, 165)]),
      ),
      child: active?? Column(
        mainAxisAlignment: MainAxisAlignment.center,
            children: [Text("What are the main building blocks of Flutter UIs ?",
              style: TextStyle(decoration: TextDecoration.none,fontSize: 30,
              color: Color.fromRGBO(246, 246, 247, 0.952)),),
              SizedBox(height: 20,),
                    ElevatedButton(onPressed: functions, child: Text("Functions"),),
                    SizedBox(height: 20,),
                    ElevatedButton(onPressed: components, child: Text("Components")),
                    SizedBox(height: 20,),
                    ElevatedButton(onPressed: blocks, child: Text("Blocks")),
                    SizedBox(height: 20,),
                    ElevatedButton(onPressed: widgets, child: Text("widgets")),
                    ],),
    );
  }
}