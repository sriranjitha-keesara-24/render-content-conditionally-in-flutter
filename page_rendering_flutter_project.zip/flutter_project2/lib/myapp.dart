import 'package:flutter/material.dart';
import 'package:flutter_project2/page1.dart';
import 'package:flutter_project2/startQuiz.dart';

class MyApp extends StatefulWidget{

  const MyApp({super.key});
  @override
  State<MyApp> createState(){
    return _TestMyApp();
  }
}
class _TestMyApp extends State<MyApp>{
  Widget? activestate;
  void switchPage(){
    setState(() {
      activestate = QuizQuestions();
    });
  }
  @override
  void initState() {
    // TODO: implement initState
    activestate = StartTest(switchPage);
    super.initState();
  }
  @override
  Widget build(BuildContext context){
       
    return MaterialApp(home: Scaffold(
    appBar: AppBar(
  centerTitle: true,
  title: Text(
    "Advance flutter",
    style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
  ),
),

    
    body: Container(
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
      gradient: LinearGradient(colors: [Color.fromARGB(217, 26, 113, 235),Color.fromARGB(184, 155, 9, 165)]),
      ),
      // child: switchPage,
      child: activestate
    ),
    ),
  );
  }
}
