import 'package:flutter/material.dart';

class Componentspage extends StatelessWidget {
  const Componentspage({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,   // expand to parent
      height: double.infinity,  // expand to parent
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color.fromARGB(210, 48, 19, 209),Color.fromARGB(211, 126, 10, 176)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      alignment: Alignment.center, // center the child
      child: const Text(
        "This is Components page",
        style: TextStyle(fontSize: 30, color: Colors.white),
      ),
    );
  }
}
