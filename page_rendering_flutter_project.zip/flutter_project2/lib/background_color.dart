import 'package:flutter/material.dart';

class BackgroundContainer extends StatelessWidget{
   const BackgroundContainer(this.child,{super.key});
   final Widget child;
  @override
  Widget build(BuildContext context){
       
    return  Container(
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
      gradient: LinearGradient(colors: [Color.fromARGB(217, 26, 113, 235),Color.fromARGB(184, 155, 9, 165)]),
      ),
      // child: StartTest(),
      child:child,
    
  );
  }
}