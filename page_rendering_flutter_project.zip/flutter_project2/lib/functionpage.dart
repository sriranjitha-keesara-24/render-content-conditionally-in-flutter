import 'package:flutter/material.dart';
import 'package:flutter_project2/page1.dart';

class FunctionsPage extends StatelessWidget{
  const FunctionsPage({super.key});
  // final void Function() activestate;

  @override
    Widget build(BuildContext context){
    return Container(
      
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
      gradient: LinearGradient(colors: [Color.fromARGB(217, 26, 113, 235),Color.fromARGB(184, 155, 9, 165)]),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
            children: [Text("This is Functions page?",
              style: TextStyle(decoration: TextDecoration.none,fontSize: 30,
              color: Color.fromRGBO(246, 246, 247, 0.952)),),
              SizedBox(height: 20,),
                    ],),
    );
  }
}