import 'package:flutter/material.dart';
import 'package:flutter_project2/startQuiz.dart';
class StartTest extends StatefulWidget{
  const StartTest({super.key});
  @override
  State<StartTest> createState(){
    return _AdvanceFlutter();
  }
}
class _AdvanceFlutter extends State<StartTest>{
  void clickOn(){
    Navigator.push(context, MaterialPageRoute(builder: (context)=>QuizQuestions()));
  }
  @override
  Widget build(BuildContext context){
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center, // the image will keep in center
        children: [
          // Opacity(opacity: 0.3,child: Image.asset("assets/images/image1.jpg"),),
          Image.asset("assets/images/image1.jpg",width: 200,height: 200,),
          SizedBox(height: 30,),
          Text("Learn flutter the fun way",style: TextStyle(fontSize: 20,color: Color.fromRGBO(244, 244, 245, 0.853)),),
          // Padding(padding:EdgeInsetsGeometry.all(20)),
          SizedBox(height: 20,),
        // ElevatedButton(onPressed: clickOn, child: Text("start Now"),),
        ElevatedButton.icon(onPressed: clickOn, 
        icon: Icon(Icons.arrow_forward),
        label: Text("next"),),
        ],
      ),
    );
  }
}



