import 'package:flutter/material.dart';

class QuizQuestions extends StatefulWidget{
  const QuizQuestions({super.key});
  @override
  State<QuizQuestions> createState(){
    return _QuizQuestionsStart();
  }
}
class _QuizQuestionsStart extends State<QuizQuestions>{
  Widget? img;
  void functions(){
    setState(() {
      img = Image.asset("assets/images/image1.jpg");
    });
  }
  void components(){

  }
  void blocks(){

  }
  void widgets(){

  }
  @override
    Widget build(BuildContext context){
    return Container(
      
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
      gradient: LinearGradient(colors: [Color.fromARGB(217, 26, 113, 235),Color.fromARGB(184, 155, 9, 165)]),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
            children: [Text("What are the main building blocks of Flutter UIs ?",
              style: TextStyle(decoration: TextDecoration.none,fontSize: 30,
              color: Color.fromRGBO(246, 246, 247, 0.952)),),
              SizedBox(height: 20,),
                    ElevatedButton(onPressed: functions, child: Text("Functions"),),
                    SizedBox(height: 20,),
                    ElevatedButton(onPressed: components, child: Text("Components")),
                    SizedBox(height: 20,),
                    ElevatedButton(onPressed: blocks, child: Text("Blocks")),
                    SizedBox(height: 20,),
                    ElevatedButton(onPressed: widgets, child: Text("widgets")),
                    ],),
    );
  }
}