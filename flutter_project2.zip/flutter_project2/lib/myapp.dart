import 'package:flutter/material.dart';
import 'package:flutter_project2/page1.dart';
import 'package:flutter_project2/startQuiz.dart';

class MyApp extends StatefulWidget{

  const MyApp({super.key});
  @override
  State<MyApp> createState(){
    return _TestMyApp();
  }
}
class _TestMyApp extends State<MyApp>{
  Widget changeText = const StartTest();
  void onClick(){
    setState(() {
      changeText = const QuizQuestions();
    });
  }
   
  @override
  Widget build(BuildContext context){
       
    return MaterialApp(home: Scaffold(
    appBar: AppBar(title: Title(color: Colors.black, child: Text("Advance flutter",style: TextStyle(fontSize: 40),)),centerTitle: true,),
    
    body: Container(
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
      gradient: LinearGradient(colors: [Color.fromARGB(217, 26, 113, 235),Color.fromARGB(184, 155, 9, 165)]),
      ),
      child: StartTest(),
      
    ),
    ),
  );
  }
}