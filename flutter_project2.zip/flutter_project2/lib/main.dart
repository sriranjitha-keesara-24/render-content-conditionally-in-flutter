
import 'package:flutter/material.dart';
import 'package:flutter_project2/myapp.dart';

void main(){
  runApp(MyApp());
  // [Color.fromRGBO(22, 31, 208, 0.747),Color.fromRGBO(77, 0, 87, 0.742)]
}